# Changelog

All notable changes to the QGIS Legend View plugin will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- `prompts/create-legend.md`: **同梱おすすめプロンプト「凡例の
  作成」**を追加。geo_driver の prompts 種別(チャット入力欄へ
  挿入する定型文)がプラグイン別 `prompts/` 集約に対応したため、
  凡例作成の定型指示を本プラグインに同梱する
- `skills/legend-creation.md`: **同梱スキル「凡例作成」**を追加。
  geo_driver の指示書集約がプラグイン別 `skills/` に対応したため、
  凡例作成の手順書を本プラグインに同梱する。
  モデルは `ai_list_instructions`→`ai_read_instruction` で
  オンデマンドに参照し、メソッド選定表(分類/階級区分/ルール/
  単一・レイアウト凡例・PNG出力)・引数形式・layer解決・
  scale_style/webgis-convert との連携を得られる

## [2.9.0] - 2026-11-16

### Added
- **凡例エクスポートの拡充**(issue #21 の残課題対応)。
  - `exportLegend(path, layers, title, dpi, format)` —
    凡例のみの画像を PNG/SVG で出力(format='png'|'svg')。
    `exportLegendImage` は format='png' の別名として維持
  - `exportLegendHtml(path, layers, title, icon_size)` —
    シンボル画像を data URI で埋め込んだ自己完結 HTML を生成。
    ブラウザ単体での表示や WebGIS/レポートへの貼り付け用
  - 凡例ドックの凡例一覧(テーブル/リスト)に右クリック
    コンテキストメニューを追加し、現在レイヤの凡例を
    PNG/SVG/HTML でエクスポートできる GUI 導線を新設
- 上記メニュー・ダイアログ用の新規文字列を i18n 全9言語
  カタログへ追加

## [2.8.0] - 2026-11-14

### Added
- `applyRules` のルール spec を拡張。`width`(線幅)・
  `width_unit`('mm'|'pixels'|'map_units'|'meters'=実世界幅)・
  `min_scale`/`max_scale`(縮尺分母の表示範囲。ルールは
  min_scale < 分母 <= max_scale で有効)を受け付けるようにし、
  縮尺帯で線幅が切替わるレンダラを作成可能にした。
  geo_driver の scale_style サービス(標準線幅テーブル)からも
  この spec で委譲される。`filter` は縮尺指定時に省略可
- `legendSpec` のルール項目に `min_scale`/`max_scale`/`width`
  を追加し、縮尺連動レンダラの内容を確認できるようにした

## [2.7.0] - 2026-11-14

### Added
- **bridge に凡例作成系メソッドを追加**(AIチャットからの凡例作成に対応)。
  - `legendSpec(layer)` — 現在のレンダラ(凡例)定義を取得
    (type/field/項目のlabel・value・lower-upper・filter・color)
  - `applyCategories(layer, field, ramp, labels, colors)` —
    属性フィールドの個別値分類レンダラを作成
  - `applyGraduated(layer, field, classes, ramp, method)` —
    数値フィールドの階級区分レンダラを作成
    (equal=等間隔 / quantile=分位数)
  - `applyRules(layer, rules, else_label)` —
    ルールベースレンダラを作成
    (rules=[{"filter","label","color"}])
  - `applySingleSymbol(layer, color)` — 単一シンボルへ戻す
  - `addLayoutLegend(layout, title, x, y, w, h, layers, linked_map,
    filter_by_map)` — 印刷レイアウトへ QgsLayoutItemLegend を追加
    (layout省略で新規レイアウト自動作成、layersで対象限定)
  - `exportLegendImage(path, layers, title, dpi)` —
    凡例のみのPNG画像を出力
- `pluginInfo` の summary/when_to_use に凡例作成用途を追記し、
  describe_plugins 経由でAIが発見できるようにした

## [2.6.9] - 2026-11-13

### Changed
- `qt_compat.py` を削除し、Qt import を `legend_view.py` /
  `legend_view_dockwidget.py` に直接展開(enum エイリアス・
  `translate`/`setLabelAlignment`/`createSymbolPreview` 等の
  ラッパも廃止し `Qt.AlignmentFlag.AlignCenter`・
  `QgsSymbolLayerUtils.symbolPreviewPixmap` を直接使用)。
  `import *` による暗黙の依存を解消

## [2.6.8] - 2026-11-13

### Changed
- **プラグイン ID を `QGIS-legendView-main` → `geo_legend` にリネーム**
  (`geo_` シリーズ統一)。フォルダ名・metadata の name・
  ブリッジ `pluginId`・`pluginInfo().id` を新IDへ移行。
  クラス名 `LegendView`・i18n コンテキスト `LegendView` は
  そのまま維持。upstream 名 `QGIS-legendView` への言及は
  出典表記として残置。機能変更なし

## [2.6.7] - 2026-11-12

### Fixed
- 個別利用時にGeoSuiteツールバーが表示されない不具合を修正。
  `_geo_toolbar()` に `ensure_visible` 引数を追加し、項目追加経路では
  ツールバーの可視状態を保証するようにした(ドライバ非稼働の個別利用では
  表示を強制する経路が無く、保存済みウィンドウ状態等でツールバーが
  非表示のままになり得た)。unload時のremoveAction経路は従来通り
  表示状態を変更しない

## [2.6.6] - 2026-10-27
- bridge.py: legend_*変数の編集/削除(setLegendVariable/
  deleteLegendVariable)・任意レイヤ登録(registerLayer)・コンボ再構築
  (refresh)を追加し、変数ダイアログの全操作をbridge_callから可能にした

## [2.6.5] - 2026-10-22

### Fixed
- i18n/ の de/es/fr/it/ja/zh に hi/pt/ru のみ存在した
  LegendView コンテキスト4キー(&Legend View/Legend/
  Other values/Symbol)の訳文を追加し、全言語で
  カタログキー数を一致させた

## [2.6.4] - 2026-10-21

### Maintenance
- try/except/pass 5箇所に # nosec B110 を付与(設計上の許容を明示)

## [2.6.3] - 2026-10-21

### Fixed
- Qt6互換性チェック対応: 非スコープ列挙型をスコープ化
  (Qgis.*→Qgis.MessageLevel.* 等3箇所)

## [2.6.2] - 2026-10-21

### Security
- plugins.qgis.org セキュリティスキャン対応: LOW指摘
  (try/except/pass)はレビュー済みの常套パターンとして
  同梱 `.bandit` 設定で抑制(ZIP内検出により
  "Validated (configured)" ステータス想定)

### Maintenance
- flake8指摘を整理: bare `except:` を `except Exception:` に、
  `== None`/`not x is None` を `is None`/`is not None` に修正、
  未使用import除去。残る慣習的指摘(長行E501、qt_compat/
  resources_rcの星import等)は同梱 `.flake8` 設定で明示抑制

## [2.6.1] - 2026-10-19

### Changed
- `create_zip.py` が metadata.txt changelog に挿入する日本語プレースホルダ
  `(ここに変更内容を記載)` を英語 `(describe changes here)` に変更。

## [2.6.0] - 2026-10-19

### Changed
- 翻訳方式を `i18n/<lang>.json` に移行(Harness横断の方針変更)。
  `.ts`/`.qm`・`i18n/LegendView.pro`・Makefileのtrans系ターゲットを廃止し、
  `{"context": {"英語ソース": "翻訳"}}` のJSONカタログを新設。
  `i18n_json.py`(全プラグイン共通ローダ)の `install_translator()` で
  起動時ロードに統一。

## [2.5.0] - 2026-10-18

### Added
- 採用言語セット(AGENTS.md)に合わせ hi/pt/ru の翻訳カタログ
  (`i18n/LegendView_<lang>.ts`/`.qm`)を追加。既存の
  de/es/fr/it/ja/zh と合わせ全9言語を同梱。

## [2.4.0] - 2026-10-18

### Changed
- 翻訳カタログ(`.ts`)を最新ソースから再抽出し、日本語および
  既存言語(de/es/fr/it/zh)の全メッセージを翻訳済みに更新。
  各言語の `.qm` を再コンパイル。

## [2.3.0] - 2026-10-18

### Changed
- ドックウィジェットの追加時、同じドックエリア(右側)に既存パネルが
  あれば `QMainWindow.tabifyDockWidget` でタブ化して追加するように変更
  (`restoreState` → `tabifyWithExistingDock` 新設。
  可視ドックを優先し、非表示のみの場合はそれにタブ化。
  既存パネルが無ければ従来通り単独追加。
  QGIS保存状態の復元に成功した場合やフローティング時は対象外)

## [2.2.0] - 2026-10-18

### Changed
- `metadata.txt` の `qgisMinimumVersion` を 3.40 → 4.0 に更新
  (QGIS4以降専用。`qgisMaximumVersion=4.99`・`supportsQt6`は継続)。
  説明文の対応範囲表記も QGIS 4.x に修正

### Removed
- **Qt5サポートを完全削除**: `qt_compat.py` をQt6専用に書き換え、
  PyQt5フォールバック・バージョン分岐(`is_qt5`/`is_qt6`)を除去。
  `qt_compat_new.py`・`resources_rc_qt5.py`・`resources_rc_qt5_test.py`・
  `metadata_qt6_only.txt` を削除。非スコープenum
  (`Qt.transparent`/`Qt.ItemIsEditable`)もQt6 enum形式に修正
- `version.py`/`version_manager.py` の互換性情報をQGIS4/Qt6専用に更新
- 旧upstream由来の `README.txt` / `README.html` を削除(README.md に統合済みのため不要)
  (version.py の値が古かったため 2.2.0 に同期)

## [2.1.0] - 2026-10-18

### Added
- AI/外部制御用ブリッジ(`bridge.py` の `LegendViewBridge`)を新設し
  `plugin.bridge` に配線。`geo_driver` の `bridge_call`
  (ファイルJSONL / REST /api/cmd / MCP `qgis_bridge_call` /
  AIアシスタントパネル)と `describe_plugins` カタログから利用可能。
  メソッド(JSON文字列返却): `pluginInfo` / `status` / `openDock` /
  `closeDock` / `listDatasets` / `selectDataset` / `legend` /
  `opacity` / `listStyles` / `setStyle` / `selectCurrentLayer` /
  `registerCurrentLayer` / `legendVariables`
- 機能変更なし(UI操作は従来通り)

## [2.0.17] - 2026-10-18

### Changed
- QGIS Live Harness (`qgis-plugin/geo_legend`) への組み込み
  - upstreamは「repoルート=プラグイン」構造のため `C:\devin\QGIS-legendView` のcloneとコピーで同期
- 機能変更なし（ドキュメント・管理構成のみ）

## [2.0.2] - 2025-07-20

### Changed
- Currentボタンの幅を1.5倍に拡大
- legend_view_dockwidget_base.uiのUI調整
- 各言語翻訳ファイルの構造修正・再生成（.ts/.qm）
- ドイツ語・イタリア語翻訳ファイルの再構築
- lreleaseによる全言語の.qm再生成
- 最新の翻訳・UI修正を反映したZIPパッケージ作成

### Fixed
- 多言語翻訳抽出・反映の不具合修正
- .tsファイルの重複・壊れたXML宣言の整理
- Currentボタンの翻訳が抽出されない問題の修正

### Added
- CHANGELOG.mdのバージョン管理手順明記
- バージョン管理スクリプトの利用例をREADME等に追記

---

## [Unreleased]

## [2.0.1] - 2025-07-13

### Fixed
- Added missing LICENSE file to plugin package
- Added README.md to plugin package for better documentation
- Enhanced ZIP package validation system

### Added
- Plugin package validator script (validate_package.py)
- Comprehensive package validation with error reporting
- Improved packaging system with all required files

## [2.0.0] - 2025-07-13

### Added
- Qt5/Qt6 compatibility support
- Multi-language support (Japanese and English)
- Python-based translation fallback system
- Automatic Qt version detection
- Comprehensive version management system
- Improved error handling and robustness

### Changed
- Default interface language changed to Japanese
- Enhanced translation system with fallback mechanisms
- Improved compatibility across QGIS versions (3.0 to 3.30+)
- Updated plugin architecture for better maintainability

### Technical Improvements
- Added `qt_compat.py` for Qt version compatibility
- Implemented `version.py` for centralized version management
- Added `translations.py` for Python-based translation fallback
- Enhanced ZIP packaging system with version awareness

### Fixed
- Translation issues in Japanese interface
- Qt version compatibility problems
- Plugin loading errors in different QGIS versions

## [1.0.0] - 2020-10-28

### Added
- Initial release
- Basic legend display functionality
- Dockable widget interface
- Project variable-based layer selection
- Support for vector and raster layers
- Opacity control
- Named style support

### Features
- Display selected layer legends in a compact widget
- Configure display order using project variables
- Support for various layer types and symbology
- Integration with QGIS layer tree

---

## Version Format

This project uses [Semantic Versioning](https://semver.org/):

- **MAJOR** version for incompatible API changes
- **MINOR** version for backward-compatible functionality additions  
- **PATCH** version for backward-compatible bug fixes

Additional labels for pre-release and build metadata:
- **alpha**, **beta**, **rc** for pre-release versions
- **build** metadata for development builds
