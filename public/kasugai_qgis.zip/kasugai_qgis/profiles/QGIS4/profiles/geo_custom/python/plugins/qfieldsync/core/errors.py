class QFieldSyncError(Exception):
    pass
