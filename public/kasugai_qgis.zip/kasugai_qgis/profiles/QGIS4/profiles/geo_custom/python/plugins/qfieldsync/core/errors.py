class QFieldSyncError(Exception):
    pass
